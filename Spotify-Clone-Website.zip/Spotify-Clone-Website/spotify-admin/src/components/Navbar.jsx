
function Navbar() {
    return (
        <nav className="w-full py-5 pl-10 border-2 border-b-black">
            Admin Panel
        </nav>
    )
}

export default Navbar